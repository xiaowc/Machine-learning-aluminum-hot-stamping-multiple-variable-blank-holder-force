from sklearn.ensemble import GradientBoostingRegressor
from normal_tools import read_data
from normal_tools import split_data
from normal_tools import save_data
from normal_tools import evaluation_standard
from normal_tools import save_all_the_data
import numpy as np


def deal_data(datapath, number):
    ratio = 0.2
    data1 = read_data.readfile(datapath)
    data1 = data1[0:number, :]
    data_Temp = data1[:, 0:-2]
    data_y = data1[:, -2]
    data_z = data1[:, -1]

    X_train1, X_test1, y_train1, y_test1 = split_data.split_data(data_Temp, data_y, ratio)
    data_thinning = [X_train1, X_test1, y_train1, y_test1]

    X_train2, X_test2, y_train2, y_test2 = split_data.split_data(data_Temp, data_z, ratio)
    data_thincking = [X_train2, X_test2, y_train2, y_test2]
    return data_thinning, data_thincking


def fun_GBRRegressor_1(data):
    reg = GradientBoostingRegressor(loss='squared_error', learning_rate=0.1, n_estimators=300,
                                    subsample=1.0, criterion='friedman_mse', min_samples_split=2,
                                    min_samples_leaf=1, min_weight_fraction_leaf=0.,
                                    max_depth=3, min_impurity_decrease=0.,
                                    init=None, random_state=None,
                                    max_features=None, alpha=0.9, verbose=0, max_leaf_nodes=None,
                                    warm_start=False, validation_fraction=0.1,
                                    n_iter_no_change=None, tol=1e-4, ccp_alpha=0.0)
    reg.fit(data[0], data[2])
    pred = reg.predict(data[1])
    MSE = evaluation_standard.fun_mean_squared_error(data[3], pred)
    RMSE = evaluation_standard.fun_root_mean_square_error(data[3], pred)
    MAE = evaluation_standard.fun_mean_absolute_error(data[3], pred)
    MAPE = evaluation_standard.fun_mean_absolute_percentage_error(data[3], pred)
    R2 = evaluation_standard.fun_r2_score(data[3], pred)

    score = [MSE, RMSE, MAE, MAPE, R2]
    return score, pred


def fun_GBRRegressor_2(data):
    reg = GradientBoostingRegressor(loss='squared_error', learning_rate=0.1, n_estimators=300,
                                    subsample=1.0, criterion='friedman_mse', min_samples_split=2,
                                    min_samples_leaf=1, min_weight_fraction_leaf=0.,
                                    max_depth=3, min_impurity_decrease=0.,
                                    init=None, random_state=None,
                                    max_features=None, alpha=0.9, verbose=0, max_leaf_nodes=None,
                                    warm_start=False, validation_fraction=0.1,
                                    n_iter_no_change=None, tol=1e-4, ccp_alpha=0.0)
    reg.fit(data[0], data[2])
    pred = reg.predict(data[1])
    MSE = evaluation_standard.fun_mean_squared_error(data[3], pred)
    RMSE = evaluation_standard.fun_root_mean_square_error(data[3], pred)
    MAE = evaluation_standard.fun_mean_absolute_error(data[3], pred)
    MAPE = evaluation_standard.fun_mean_absolute_percentage_error(data[3], pred)
    R2 = evaluation_standard.fun_r2_score(data[3], pred)

    score = [MSE, RMSE, MAE, MAPE, R2]
    return score, pred


if __name__ == '__main__':
    h = [1000]
    for i in h:
        print(i)
        b = str(i)
        datapath = "G:/papers/automatic optimization/force/Code/data.csv"
        path2_thin = 'data/GBR_BEST_param_result/' + b + '/predict data/thinning'
        path3_thin = 'data/GBR_BEST_param_result/' + b + '/score/thinning'
        path2_thinck = 'data/GBR_BEST_param_result/' + b + '/predict data/thickening'
        path3_thinck = 'data/GBR_BEST_param_result/' + b + '/score/thickening'
        # data = [X_train, X_test, y_train, y_test]
        result = []

        R = []
        R.append(i)
        score_thinning = []
        score_thincking = []

        for j in range(50):
            data_thinning, data_thincking = deal_data(datapath, i)
            score1, pred_thin = fun_GBRRegressor_1(data_thinning)
            data_real_pred_thin = zip(data_thinning[1], data_thinning[3], pred_thin)
            save_all_the_data.save_all_data_two(i, j, path2_thin, data_real_pred_thin)
            score_thinning.append(score1)

            score2, pred_thinck = fun_GBRRegressor_2(data_thincking)
            data_real_pred_thick = zip(data_thincking[1], data_thincking[3], pred_thinck)
            save_all_the_data.save_all_data_two(i, j, path2_thinck, data_real_pred_thick)
            score_thincking.append(score2)

        save_all_the_data.save_all_data_one(i, path3_thin, score_thinning)
        average_score_thinning = np.array(score_thinning).mean(axis=0)
        R.extend(average_score_thinning)
        print("GBR_Regressor predict thinning：", average_score_thinning)

        save_all_the_data.save_all_data_one(i, path3_thinck, score_thincking)
        average_score_thincking = np.array(score_thincking).mean(axis=0)
        R.extend(average_score_thincking)
        print("GBR_Regressor predict thincking：", average_score_thincking)

        result.append(R)
        path = 'data/GBR_BEST_param_result/' + b + '/result.csv'
        save_data.save_data(path, result)
        print("finish")